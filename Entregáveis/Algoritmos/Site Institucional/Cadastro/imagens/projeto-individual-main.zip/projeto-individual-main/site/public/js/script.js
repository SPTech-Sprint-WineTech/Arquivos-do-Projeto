window.addEventListener("blur", function(){
    document.title = "Ola Mundo"
});
window.addEventListener("focus", function(){
    document.title = "Escoteiros do brasil"
});